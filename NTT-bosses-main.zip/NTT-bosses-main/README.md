# NTT-bosses

Modified from ideaot's Chaos Fusion
