# NTT-boss

Modified from Yokin's popo
