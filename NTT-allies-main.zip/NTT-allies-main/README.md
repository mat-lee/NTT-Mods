# NTT-allies

Modified from Yokin's popo mod
