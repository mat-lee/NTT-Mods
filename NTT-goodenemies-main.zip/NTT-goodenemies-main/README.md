# NTT-goodenemies
Modified from blaac's pyromancer
